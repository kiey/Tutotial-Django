from django.apps import AppConfig


class RecetaConfig(AppConfig):
    name = 'receta'
